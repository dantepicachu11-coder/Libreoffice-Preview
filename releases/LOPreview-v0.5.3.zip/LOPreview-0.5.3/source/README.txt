Source files (optional, for developers and auditors)
=====================================================

The two files at the release root, lo-explorer-preview.wh.cpp and
lo-preview-broker.wh.cpp, are GENERATED single-file Windhawk mods and are all
a normal user needs. They are assembled from:

    source/src/prevhost-mod.wh.cpp + src/lop_core.h + src/lop_win.h
        -> lo-explorer-preview.wh.cpp   (include list: prevhost.exe)
    source/src/broker-mod.wh.cpp   + src/lop_core.h + src/lop_win.h
        -> lo-preview-broker.wh.cpp   (include list: explorer.exe)

To regenerate after editing anything in source/src, from this "source"
directory:

    python3 tools/assemble.py

and copy the two regenerated files one level up (the release root), replacing
the shipped copies. On Windows you can instead run installer\build-mod.ps1
from a normal repository checkout (it expects the repository layout with
src/ and installer/ as siblings).

source/tests contains the portable unit tests, the stub Windows SDK used for
an offline syntax compile, and the static consistency checks. Run everything
without Windows via:

    tests/run-all.sh
